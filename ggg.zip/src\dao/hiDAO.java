package dao;

public class hiDAO{
	init ;


	public init (){

	}

}