package dao;

public class ExamDAO{
	int value1;
	String value2;


	public void method1(){

	}

	public int method2(){

	}

}