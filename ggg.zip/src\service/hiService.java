package service;

import dao.hiDAO;
public class hiService{
	hiDAO hiDAO=new hiDAO();
	init ;


	public init (){

	}

}