package service;

import dao.ExamDAO;
public class ExamService{
	ExamDAO examDAO=new ExamDAO();
	int value1;
	String value2;


	public void method1(){

	}

	public int method2(){

	}

}