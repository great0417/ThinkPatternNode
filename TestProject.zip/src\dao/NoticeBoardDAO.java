package dao;


public class NoticeBoardDAO{
	String Title;
	String Contents;


	public void Insert(){
		
	}

}