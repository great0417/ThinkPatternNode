package service;

import dao.NoticeBoardDAO;

public class NoticeBoardService{
	NoticeBoardDAO noticeBoardDAO=new NoticeBoardDAO();
	String Title;
	String Contents;


	public void Insert(){
		
	}

}