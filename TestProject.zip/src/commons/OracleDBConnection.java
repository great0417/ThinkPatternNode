package commons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OracleDBConnection implements IDBConnection{

	private static final String CONNECT = "jdbc:oracle:thin:@localhost:1521:xe";
	private static final String USER = "YJY";
	private static final String PASSWD = "yjy";
	private Connection conn;

	@Override
	public Connection getDBConnection() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(CONNECT, USER, PASSWD);
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("DB Connect Error!!!");
		} catch (ClassNotFoundException e) {
			System.out.println("Library Load Fail");
		}

		return conn;
	}

}
