package commons;

import java.sql.Connection;


public interface IDBConnection {
	
	Connection getDBConnection();
	
}
