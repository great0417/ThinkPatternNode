package service;
public class TESTService{
	;
	value2;


	public (){

	}

	public method2(){

	}

}