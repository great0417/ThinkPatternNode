package controller;
public class TESTController{
	;
	value2;


	public (){

	}

	public method2(){

	}

}