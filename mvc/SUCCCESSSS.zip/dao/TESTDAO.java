package dao;
public class TESTDAO{
	;
	value2;


	public (){

	}

	public method2(){

	}

}