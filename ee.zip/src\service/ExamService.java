package service;

import dao.ExamDAO;

public class ExamService{
	ExamDAO examDAO=new ExamDAO();


	public void method1(){
		
	}

	public int method2(){
		return 1;
	}

}