package service;
public class ExamService{
	value1;
	value2;


	public method1(){

	}

	public method2(){

	}

}