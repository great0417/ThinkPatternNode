package service;
public class fffService{
	;
	value2;


	public (){

	}

	public method2(){

	}

}