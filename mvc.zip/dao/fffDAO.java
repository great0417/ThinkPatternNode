package dao;
public class fffDAO{
	;
	value2;


	public (){

	}

	public method2(){

	}

}