package dao;
public class ExamDAO{
	value1;
	value2;


	public method1(){

	}

	public method2(){

	}

}