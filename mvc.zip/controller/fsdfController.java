package controller;
public class fsdfController{
	;
	value2;


	public (){

	}

	public method2(){

	}

}