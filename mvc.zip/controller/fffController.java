package controller;
public class fffController{
	;
	value2;


	public (){

	}

	public method2(){

	}

}