package controller;
public class ExamController{
	value1;
	value2;


	public method1(){

	}

	public method2(){

	}

}